<?php

namespace App\Services\Web\Admin;

class OrderService
{
    public function __construct()
    {
        
    }
}
