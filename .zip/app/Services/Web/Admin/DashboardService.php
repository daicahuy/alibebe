<?php

namespace App\Services\Web\Admin;

class DashboardService
{
    public function __construct()
    {
        
    }
}
