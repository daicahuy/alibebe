/*=====================
    Delivery Option Hide & Show js
   ==========================*/
$(".show-box-checked").click(function () {
    $(".future-box").addClass("show");
});
$(".hide-check-box").click(function () {
    $(".future-box").removeClass("show");
});