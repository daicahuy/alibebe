$(".checkall").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall1").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it1").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it1").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall2").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it2").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it2").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall3").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it3").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it3").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall3").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it3").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it3").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall3").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it3").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it3").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall4").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it4").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it4").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall5").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it5").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it5").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall6").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it6").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it6").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall7").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it7").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it7").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall8").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it8").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it8").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall9").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it9").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it9").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall10").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it10").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it10").each(function () {
            $(this).prop("checked", false);
        });
    }
});

$(".checkall11").change(function () {
    var checked = $(this).is(":checked");
    if (checked) {
        $(".check-it11").each(function () {
            $(this).prop("checked", true);
        });

    } else {
        $(".check-it11").each(function () {
            $(this).prop("checked", false);
        });
    }
});