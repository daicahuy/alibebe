"use strict";
setTimeout(function () {
    (function ($) {
        "use strict";
        // Single Search Select
        $(".select2").select2({
            width: "100%",
            search: false,
        });
    })(jQuery);
}, 350);
